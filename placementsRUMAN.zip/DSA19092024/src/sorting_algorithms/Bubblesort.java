package sorting_algorithms;

import java.util.Scanner;

public class Bubblesort {
	
	//put the maximum element of the array at the end by adjacent swapping
	//average and worst case timecomplexity O(n^2)
	
	//Best case time complexity O(n) when the array is sorted such as 1,2,3,4
	//no swap happens 
	
	public static void Bubble_sort(int arr[],int n) {
		
		//edge case if array is already sorted timecomplexity is O(n);
		
		int didSwap=0;
		
		for(int i=n-1;i>=1;i--) {
			
			for(int j=0;j<i-1;j++) {
				
				if(arr[j]>arr[j+1]) {
					int temp=arr[j+1];
					arr[j+1]=arr[j];
					arr[j]=temp;
					
					didSwap=1;
				}
			}
			if(didSwap==0) {
				break;
			}
		}
		System.out.println("did it swap (1 for yes  or 0 for no) :" +didSwap);
		
		
	}
	
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the size of the array");
		int n =sc.nextInt();
		
		
		int arr[]=new int[n];
		System.out.println("Enter the array elements");
		
		for(int i=0;i<n;i++) {
			arr[i]=sc.nextInt();
		}
		
		Bubble_sort(arr,n);
		System.out.println("After sorting");
		for(int i=0;i<n;i++) {
			System.out.print(arr[i] + " ");
		}
	}

}
